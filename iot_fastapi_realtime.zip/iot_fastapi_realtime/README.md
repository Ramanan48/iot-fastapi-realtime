# IoT Realtime Server (FastAPI + Mongo + MQTT + Socket.IO)

Features
- User auth with JWT (register/login)
- Per-user projects with API keys and custom fields
- MQTT ingest (iot/{projectId}/{deviceId}/telemetry) → MongoDB → Socket.IO broadcast to browser
- REST ingest fallback: `POST /api/ingest/{api_key}`
- Control path: HTTP → retained MQTT `iot/{projectId}/{deviceId}/control` + UI switches
- Live charts with Chart.js
- CSV export

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env  # edit if needed (Mongo/MQTT/admin)
uvicorn app.main:app --reload
```
Open http://localhost:8000

## MQTT Topics
- Telemetry (device→server): `iot/{projectId}/{deviceId}/telemetry` JSON payload
- Control (server→device):   `iot/{projectId}/{deviceId}/control` retained JSON, e.g. `{ "pump": true }`

## Example ESP32 (pseudo)
- Connect to broker, publish telemetry every N seconds.
- Subscribe to your `.../control` topic, apply states on message.
