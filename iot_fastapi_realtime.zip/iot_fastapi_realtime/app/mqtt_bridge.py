import threading, json, time, ssl
from typing import Callable
import paho.mqtt.client as mqtt
from .settings import settings

# Topic scheme:
# Telemetry publish by MCU: iot/{projectId}/{deviceId}/telemetry
# Control from server:       iot/{projectId}/{deviceId}/control  (retained)

class MQTTBridge:
    def __init__(self):
        self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="iot-server")
        if settings.MQTT_USERNAME:
            self.client.username_pw_set(settings.MQTT_USERNAME, settings.MQTT_PASSWORD or "")
        if settings.MQTT_TLS:
            self.client.tls_set(cert_reqs=ssl.CERT_REQUIRED)
        self._on_telemetry: Callable[[str, dict], None] = lambda topic, payload: None
        self.thread = None

        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message

    def start(self, on_telemetry: Callable[[str, dict], None]):
        self._on_telemetry = on_telemetry
        self.client.connect(settings.MQTT_HOST, settings.MQTT_PORT, keepalive=60)
        self.thread = threading.Thread(target=self.client.loop_forever, daemon=True)
        self.thread.start()

    def _on_connect(self, client, userdata, flags, reason_code, properties):
        # Subscribe to all telemetry topics
        client.subscribe("iot/+/+/telemetry", qos=1)

    def _on_message(self, client, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
        except Exception:
            payload = {"raw": msg.payload.decode(errors="ignore")}
        self._on_telemetry(msg.topic, payload)

    def publish_control(self, project_id: str, device_id: str, state: dict, retain: bool=True):
        topic = f"iot/{project_id}/{device_id}/control"
        self.client.publish(topic, json.dumps(state), qos=1, retain=retain)


mqtt_bridge = MQTTBridge()
