from bson import ObjectId

def oid(obj) -> str:
    return str(obj) if isinstance(obj, ObjectId) else str(ObjectId(obj))
