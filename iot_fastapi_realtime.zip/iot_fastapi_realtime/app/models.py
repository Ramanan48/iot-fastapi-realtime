from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

class RegisterIn(BaseModel):
    email: EmailStr
    password: str

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: str
    email: EmailStr
    is_admin: bool

class ProjectCreate(BaseModel):
    name: str = Field(..., max_length=120)
    description: Optional[str] = None
    fields: Optional[List[str]] = None  # telemetry field names

class ProjectOut(BaseModel):
    id: str
    name: str
    description: Optional[str]
    api_key: str
    fields: List[str]
    created_at: datetime

class TelemetryIn(BaseModel):
    payload: Dict[str, Any]

class ControlSetIn(BaseModel):
    name: str
    state: bool
