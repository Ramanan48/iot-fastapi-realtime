import socketio

# Async Socket.IO server, CORS open for demo (adjust in prod)
sio = socketio.AsyncServer(async_mode="asgi", cors_allowed_origins="*")
app_sio = socketio.ASGIApp(sio)

# Rooms:
#  - project:<projectId> for dashboards of a project
#  - device:<projectId>:<deviceId> if you want per-device rooms

@sio.event
async def connect(sid, environ, auth):
    # Client may send { projectId } in auth to auto-join
    try:
        project_id = (auth or {}).get("projectId")
        if project_id:
            await sio.enter_room(sid, f"project:{project_id}")
    except Exception:
        pass

@sio.event
async def join_project(sid, data):
    project_id = str(data.get("projectId"))
    await sio.enter_room(sid, f"project:{project_id}")

@sio.event
async def leave_project(sid, data):
    project_id = str(data.get("projectId"))
    await sio.leave_room(sid, f"project:{project_id}")
