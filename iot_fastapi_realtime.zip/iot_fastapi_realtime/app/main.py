from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from bson import ObjectId
from datetime import datetime
from uuid import uuid4
import json

from .settings import settings
from .db import users, projects, data, controls
from .auth import create_jwt, verify_password, hash_password, get_current_user, require_admin
from .models import RegisterIn, LoginIn, UserOut, ProjectCreate, ProjectOut, TelemetryIn, ControlSetIn
from .mqtt_bridge import mqtt_bridge
from .socket import sio, app_sio

app = FastAPI(title="IoT FastAPI Realtime")

# Mount Socket.IO app
app.mount("/ws", app_sio)

# Static & templates
app.mount("/static", StaticFiles(directory="public"), name="static")
templates = Jinja2Templates(directory="public")

# ---------------- Boot admin & MQTT ----------------
@app.on_event("startup")
async def startup():
    # Create admin if missing
    if not await users.find_one({"email": settings.ADMIN_EMAIL.lower()}):
        await users.insert_one({
            "email": settings.ADMIN_EMAIL.lower(),
            "password": hash_password(settings.ADMIN_PASSWORD),
            "is_admin": True,
            "created_at": datetime.utcnow()
        })
    # Start MQTT bridge
    def on_telemetry(topic: str, payload: dict):
        # topic: iot/{projectId}/{deviceId}/telemetry
        try:
            _, project_id, device_id, _ = topic.split("/", 3)
        except ValueError:
            return
        doc = {
            "project_id": project_id,
            "device_id": device_id,
            "ts": datetime.utcnow(),
            "payload": payload
        }
        # Store
        import asyncio
        loop = asyncio.get_event_loop()
        loop.create_task(data.insert_one(doc))
        # Emit to dashboards subscribed to this project
        loop.create_task(sio.emit("telemetry", {"projectId": project_id, "deviceId": device_id, "point": {
            "ts": doc["ts"].isoformat(), **payload
        }}, room=f"project:{project_id}"))
    mqtt_bridge.start(on_telemetry)

# ---------------- HTML PAGES ----------------
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/project/{project_id}", response_class=HTMLResponse)
async def project_page(request: Request, project_id: str):
    return templates.TemplateResponse("project.html", {"request": request, "project_id": project_id})

# ---------------- AUTH API ----------------
@app.post("/api/auth/register")
async def api_register(body: RegisterIn):
    email = body.email.lower()
    if await users.find_one({"email": email}):
        raise HTTPException(400, "Email already registered")
    await users.insert_one({
        "email": email,
        "password": hash_password(body.password),
        "is_admin": False,
        "created_at": datetime.utcnow()
    })
    user = await users.find_one({"email": email})
    token = create_jwt(str(user["_id"]), is_admin=user.get("is_admin", False))
    return {"token": token}

@app.post("/api/auth/login")
async def api_login(body: LoginIn):
    email = body.email.lower()
    user = await users.find_one({"email": email})
    if not user or not verify_password(body.password, user["password"]):
        raise HTTPException(401, "Invalid credentials")
    token = create_jwt(str(user["_id"]), is_admin=user.get("is_admin", False))
    return {"token": token}

@app.get("/api/me")
async def api_me(claims: dict = Depends(get_current_user)):
    u = await users.find_one({"_id": ObjectId(claims["sub"])})
    return {"id": str(u["_id"]), "email": u["email"], "is_admin": u.get("is_admin", False)}

# ---------------- PROJECTS ----------------
@app.post("/api/projects", response_model=ProjectOut)
async def create_project(body: ProjectCreate, claims: dict = Depends(get_current_user)):
    fields = body.fields or ["value"]
    doc = {
        "user_id": ObjectId(claims["sub"]),
        "name": body.name,
        "description": body.description,
        "api_key": uuid4().hex,
        "fields": fields,
        "created_at": datetime.utcnow()
    }
    res = await projects.insert_one(doc)
    # create default control
    await controls.update_one(
        {"project_id": str(res.inserted_id), "name": "switch1"},
        {"$setOnInsert": {"state": False, "updated_at": datetime.utcnow()}},
        upsert=True
    )
    p = await projects.find_one({"_id": res.inserted_id})
    return {
        "id": str(p["_id"]), "name": p["name"], "description": p.get("description"),
        "api_key": p["api_key"], "fields": p["fields"], "created_at": p["created_at"]
    }

@app.get("/api/projects", response_model=list[ProjectOut])
async def list_projects(claims: dict = Depends(get_current_user)):
    cur = projects.find({"user_id": ObjectId(claims["sub"])}).sort("created_at", -1)
    out = []
    async for p in cur:
        out.append({
            "id": str(p["_id"]), "name": p["name"], "description": p.get("description"),
            "api_key": p["api_key"], "fields": p["fields"], "created_at": p["created_at"]
        })
    return out

@app.delete("/api/projects/{project_id}")
async def delete_project(project_id: str, claims: dict = Depends(get_current_user)):
    p = await projects.find_one({"_id": ObjectId(project_id), "user_id": ObjectId(claims["sub"])})
    if not p:
        raise HTTPException(404, "Not found")
    await data.delete_many({"project_id": project_id})
    await controls.delete_many({"project_id": project_id})
    await projects.delete_one({"_id": p["_id"]})
    return {"ok": True}

# ---------------- TELEMETRY (REST fallback) ----------------
@app.post("/api/ingest/{api_key}")
async def ingest(api_key: str, body: TelemetryIn):
    p = await projects.find_one({"api_key": api_key})
    if not p:
        raise HTTPException(404, "Invalid API key")
    doc = {
        "project_id": str(p["_id"]),
        "device_id": "rest",
        "ts": datetime.utcnow(),
        "payload": body.payload
    }
    await data.insert_one(doc)
    # Emit to dashboard
    await sio.emit("telemetry", {"projectId": str(p["_id"]), "deviceId": "rest", "point": {"ts": doc["ts"].isoformat(), **body.payload}}, room=f"project:{str(p['_id'])}")
    return {"ok": True, "ts": doc["ts"].isoformat()}

# ---------------- CONTROL API (HTTP -> MQTT) ----------------
@app.get("/api/control/{api_key}")
async def get_control(api_key: str):
    p = await projects.find_one({"api_key": api_key})
    if not p:
        raise HTTPException(404, "Invalid API key")
    project_id = str(p["_id"])
    cur = controls.find({"project_id": project_id})
    out = {}
    async for c in cur:
        out[c["name"]] = bool(c.get("state", False))
    return out

@app.post("/api/control/{api_key}")
async def set_control(api_key: str, body: ControlSetIn):
    p = await projects.find_one({"api_key": api_key})
    if not p:
        raise HTTPException(404, "Invalid API key")
    project_id = str(p["_id"])
    await controls.update_one(
        {"project_id": project_id, "name": body.name},
        {"$set": {"state": body.state, "updated_at": datetime.utcnow()}},
        upsert=True
    )
    # Publish to MQTT retained
    mqtt_bridge.publish_control(project_id, device_id="any", state={body.name: body.state}, retain=True)
    # Echo to dashboards
    await sio.emit("control", {"projectId": project_id, "name": body.name, "state": body.state}, room=f"project:{project_id}")
    return {"ok": True}

# ---------------- EXPORT ----------------
@app.get("/api/export/{project_id}.csv")
async def export_csv(project_id: str, claims: dict = Depends(get_current_user)):
    p = await projects.find_one({"_id": ObjectId(project_id), "user_id": ObjectId(claims['sub'])})
    if not p:
        raise HTTPException(404, "Not found")
    import csv, io
    mem = io.StringIO()
    writer = csv.writer(mem)
    fields = ["ts"] + p.get("fields", ["value"])
    writer.writerow(fields)
    async for row in data.find({"project_id": project_id}).sort("ts", 1):
        payload = row.get("payload", {})
        writer.writerow([row["ts"].isoformat()] + [payload.get(f) for f in fields[1:]])
    mem.seek(0)
    from fastapi.responses import StreamingResponse
    return StreamingResponse(iter([mem.read()]), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=project_{project_id}.csv"})
